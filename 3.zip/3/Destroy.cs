using UnityEngine;

public class Destroy : MonoBehaviour
{
    // Метод Start вызывается один раз в начале игры.
    void Start()
    {
        // Уничтожаем игровой объект в начале игры
        Destroy(gameObject);
    }
}