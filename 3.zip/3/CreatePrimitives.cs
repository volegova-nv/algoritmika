using UnityEngine;

public class CreatePrimitives : MonoBehaviour
{
    // Метод Start вызывается один раз в начале игры.
    void Start()
    {
        GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.transform.position = new Vector3(0, 0, 0);

        GameObject head = GameObject.CreatePrimitive(PrimitiveType.Cube);
        head.transform.position = new Vector3(-0.5f, 1, 0);

        GameObject body = GameObject.CreatePrimitive(PrimitiveType.Cube);
        body.transform.position = new Vector3(0.5f, 1, 0);

        GameObject leftLeg = GameObject.CreatePrimitive(PrimitiveType.Cube);
        leftLeg.transform.position = new Vector3(0.5f, 2, 0);

        GameObject rightLeg = GameObject.CreatePrimitive(PrimitiveType.Cube);
        rightLeg.transform.position = new Vector3(-0.5f, 2, 0);

        GameObject armLeft = GameObject.CreatePrimitive(PrimitiveType.Cube);
        armLeft.transform.position = new Vector3(0, 3, 0);
    }
    //Комментарий к командам: В этом коде мы создаем класс CreatePrimitives, который наследуется от класса MonoBehaviour. В методе Start, который вызывается один раз в начале игры, мы создаем шесть кубов с различными позициями, чтобы сформировать фигуру, напоминающую Стива из Minecraft. Каждый куб создается с помощью метода GameObject.CreatePrimitive, который возвращает новый игровой объект типа куба. Затем мы устанавливаем позицию каждого куба, чтобы расположить их в нужном месте для создания фигуры.
}
