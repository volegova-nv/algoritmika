using UnityEngine;

public class Crickets : MonoBehaviour
{
    // Метод Update вызывается каждый кадр, когда игра запущена.
    void Update()
    {
        // Выводим слово "crickets" в консоль каждый кадр
        Debug.Log("crickets");
    }
}